/* @flow */

export const inBrowser = typeof window !== 'undefined'
