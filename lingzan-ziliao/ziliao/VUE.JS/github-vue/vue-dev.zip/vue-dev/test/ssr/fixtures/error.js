throw new Error('foo')
