# Flex 布局在线测试

## 介绍

![](demo.gif)

## 演示地址

[演示地址](https://ihuangmx.gitbooks.io/front-demo/content/zen-flex-demo.html#flex-布局在线测试)

## 实现

Vue + Bulma
